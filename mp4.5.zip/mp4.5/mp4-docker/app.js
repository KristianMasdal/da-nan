'use strict';
var express = require('express');
var sqlite3 = require('sqlite3').verbose();
var node = require("deasync");
var js2xmlparser = require('js2xmlparser');
var bodyParser = require('body-parser');
var md5 = require('md5');
var xmlparser = require('express-xml-bodyparser');
var cookieParser = require('cookie-parser');
var parseString = require('xml2js').parseString;
var jsonFind = require('json-find');
const methodOverride = require('method-override');

node.loop = node.runLoopOnce;
// var xml = require('xml');
var row = "";
var validLogin = false;
var app = express();
//app.use(xmltojs());
app.use(xmlparser());
app.use(cookieParser())
//app.use(bodyParser.urlencoded({extend: false}));
//app.use(bodyParser.json());
// Override header i request
app.use(methodOverride('_method'));

// Kobler til databasefila
var db = new sqlite3.Database('./bokbase', (err) => {
    if (err) {
        return console.error(err.message);
    }

    console.log('Connected to the in-memory SQlite database.\n');
});

app.listen(3000, function() {
    console.log('Server started on port 3000');
});


//LOGIN

app.post('/login', function(req, res) {
    //console.log(xmlparser(req.body));
    //console.log(req.header);
    console.log(req.body);
    console.log(req.body.login.userid[0]);
    var branavna = jsonFind(req.body.login);
    console.log(branavna.checkKey('userid'));

    var sql = `SELECT userID,
                passwordhash FROM user 
                WHERE userID = ? AND passwordhash = ?`
    var xml = xmlparser(req.body)
    var data = {
        usr: req.body.login.userid[0],
        pw: req.body.login.password[0]
    }

    //var SQL = `INSERT INTO book(bookID, title, authorID) VALUES (?,?,?);`;
    var params = [data.usr, md5(data.pw)];
    db.serialize(function() {
        db.get(sql, params, (err, result) => {
            console.log(data.usr);
            console.log(data.pw);

            if (result != null){
                console.log("Valid login");
                console.log(req.cookie);
                sql = `INSERT INTO session (
                sessionID,
                userID)
                VALUES (
                ?,
                ?);`
                var sesj = Math.random()
                params = [sesj, data.usr]
                db.run(sql, params, (err, result) => {
                    console.log(result);
                })
                res.cookie("SessionID", sesj).send("ok");
            } else if (err) {
                console.error(err.message);
            } else {
                console.log(sql);
                console.log("NOT Valid login, setting sessionID to 0");
                res.cookie('sessionId', '999').send('Set-Cookie: SessionID=0');
            }
        });
    });
})



app.get('/authors/all', function(req, res) {

    console.log("Entered get for find all authors");
    res.set('Content-type', 'text/xml');
    var xmlFile = '<?xml version="1.0" encoding="UTF-8"?>';
    xmlFile += '<authorlist>';
    var done = 0;
    var SQL = `SELECT authorID as id,
        firstname as fName,
        lastname as lName,
        nationality as nat FROM author`

    db.serialize(function() {
        db.each(SQL, (err, row) => {
            if (err) {
                console.error(err.message);
            }
            xmlFile += '<author>';
            xmlFile += '<authorid>' + row.id + '</authorid>';
            xmlFile += '<firstname>' + row.fName + '</firstname>';
            xmlFile += '<lastname>' + row.lName + '</lastname>';
            xmlFile += '<nationality>' + row.nat + '</nationality>'
            xmlFile += '</author>';
            done = 1;
        });

        while(!done) {
            node.loop();
        }

        xmlFile += '</authorlist>';
        res.send(xmlFile);
    });
});

app.get('/books/all', function(req, res) {

    console.log("Entered get for find all books");
    res.set('Content-type', 'text/xml');
    var xmlFile = '<?xml version="1.0" encoding="UTF-8"?>';
    xmlFile += '<booklist>';
    var done = 0;
    var SQL = `SELECT bookID as id,
        title as title,
        authorID as aId FROM book`;

    db.serialize(function() {
        db.each(SQL, (err, row) => {
            if (err) {
                console.error(err.message);
            }
            xmlFile += '<book>';
            xmlFile += '<bookid>' + row.id + ' </bookid>';
            xmlFile += '<booktitle>' + row.title + ' </booktitle>';
            xmlFile += '<authorId>' + row.aId + ' </authorId>';
            xmlFile += '</book>';
            done = 1;
        });

        while(!done) {
            node.loop();
        }

        xmlFile += '</booklist>';
        res.send(xmlFile);
    });
});

/*
*   GET
*/

app.get('/:table/:id', function(req, res) {

    console.log("Entered app.get");
    res.set('Content-type', 'text/xml');
    var id = req.param('id');
    var table = req.param('table');
    var idType = req.param('table')+"Id";

    console.log(`${table} from request: ${id} `);
    var xmlFile = '<?xml version="1.0" encoding="UTF-8"?>';
    
    switch(table) {
        case "books":
            var SQL = `SELECT bookID as id,
                title as booktitle,
                authorID as aId FROM book
                WHERE bookID = ?`;
            console.log(SQL);
            
            db.serialize(function() {
                db.get(SQL, [id], (err, row) => {
                    if (err) {
                        console.error(err.message);
                    }
                    var parsedxml = js2xmlparser.parse("book", row);
                    console.log(parsedxml);
                    res.send(parsedxml);
                });
            });
            break;

        case "authors":
            var SQL = `SELECT authorID as aId,
                    firstname as firstname,
                    lastname as lastname,
                    nationality as nationality FROM author
                    WHERE authorID = ?`;
                console.log(SQL);

                db.serialize(function() {
                    db.get(SQL, [id], (err, row) => {
                        if (err) {
                            console.error(err.message);
                        }
                        xmlFile += '<author>';
                        xmlFile += '<authorid>' + row.aId + ' </authorid>';
                        xmlFile += '<firstname>' + row.firstname + ' </firstname>';
                        xmlFile += '<lastname>' + row.lastname + ' </lastname>';
                        xmlFile += '<nationality>' + row.nationality + ' </lastname>';
                        xmlFile += '</author>';
                        console.log("res: " + res);
                        console.log("xmlfile: " + xmlFile);
                        var parsedxml = js2xmlparser.parse("author", row);
                        console.log(parsedxml);
                        res.send(parsedxml);
                    });
                });
            break;
        default:
            res.send("I am error");
            break;
    }
});

/*
*   POST
*/

app.post('/:books/:id', function(req, res) {
    //console.log("POST " + req.param('id') +" "+ req.param('table'));
    res.set('Content-type', 'text/xml');
    const { table, id } = req;
    console.log("const: " + table);
    var xmlFile = '<?xml version="1.0" encoding="UTF-8"?>';
    
    var data = {
        bookID: req.body.bookID,
        title: req.body.title,
        authorID: req.body.authorID
    }

    var SQL = `INSERT INTO book(bookID, title, authorID) VALUES (?,?,?);`;
    var params = [data.bookID, data.title, data.authorID];
    console.log("query:\n" + SQL);
    db.serialize(function() {
        db.run(SQL, params, (err, result) => {
            if (err) {
                console.error(err.message);
            }
            console.log("res: " + res);
            console.log("xmlfile: " + xmlFile);
            //res.send(xmlFile);
            res.json({
                "message": "success",
                "data": data,
                "id" : this.lastID
            })
        });
    });
    //res.send(1);
});
/*
*   PUT
*/
app.put('/books', function(req, res) {
    console.log("Entered put");
    res.set('Content-type', 'text/xml');
    const { table, id } = req;
    var xmlFile = '<?xml version="1.0" encoding="UTF-8"?>';    
    
    var data = {

        booktitle: req.body.booktitle,
        authorID: req.body.authorID,
        bookID: req.body.bookID
    }
    if (req.body.booktitle) {
    var SQL = `UPDATE book SET title = ? WHERE bookID = ?`;
    console.log("###put### Title: " + data.booktitle);
    var params = [data.booktitle, data.bookID];
    console.log("data: " + data.t) + "id: " + id;
    db.serialize(function() {
        db.run(SQL, params, (err) => {
            if (err) {
                console.error(err.message);
            }

            console.log("res: " + res);
            console.log("xmlfile: " + xmlFile);
            //res.send(xmlFile);
        });

    });
        
    }
    if (req.body.authorID) {
    var SQL = `UPDATE book SET authorID = ? WHERE bookID = ?`;
    console.log("###put### Title: " + data.authorID);
    var params = [data.authorID, data.bookID];
    console.log("data: " + data.t) + "id: " + id;
    db.serialize(function() {
        db.run(SQL, params, (err) => {
            if (err) {
                console.error(err.message);
            }

            console.log("res: " + res);
            console.log("xmlfile: " + xmlFile);
            console.log(SQL);
            //res.send(xmlFile);
            res.json({
                "message": "success",
                "data": data
            })
        });

    });
        
    }
    
    
});

/*
*   DELETE
*/
app.delete('/:table/:id', function(req, res) {
    console.log("DELETE " + req.param('id') +" "+ req.param('table'));
    res.send("delete");
});

// db.close((err) => {
//     if (err) {
//         return console.error(err.message);
//     }
//     console.log('\nClose the database connection.');
// });