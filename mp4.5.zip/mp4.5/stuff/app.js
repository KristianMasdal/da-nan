'use strict';
var express = require('express');
var sqlite3 = require('sqlite3').verbose();
var node = require("deasync");
var js2xmlparser = require('js2xmlparser');
var bodyParser = require('body-parser');
const methodOverride = require('method-override');

node.loop = node.runLoopOnce;
// var xml = require('xml');
var row = "";
var app = express();
app.use(bodyParser.urlencoded({extend: false}));
app.use(bodyParser.json());
// Override header i request
app.use(methodOverride('_method'));

// Kobler til databasefila
var db = new sqlite3.Database('./bokbase', (err) => {
    if (err) {
        return console.error(err.message);
    }
    console.log('Connected to the in-memory SQlite database.\n');
});

app.listen(3000, function() {
    console.log('Server started on port 3000');
});

app.get('/authors/all', function(req, res) {

    console.log("Entered get for find all authors");
    res.set('Content-type', 'text/xml');
    var xmlFile = '<?xml version="1.0" encoding="UTF-8"?>';
    xmlFile += '<authorlist>';
    var done = 0;
    var SQL = `SELECT authorID as id,
        firstname as fName,
        lastname as lName,
        nationality as nat FROM author`;

    db.serialize(function() {
        db.each(SQL, (err, row) => {
            if (err) {
                console.error(err.message);
            }
            xmlFile += '<author>';
            xmlFile += '<authorid>' + row.id + '</authorid>';
            xmlFile += '<firstname>' + row.fName + '</firstname>';
            xmlFile += '<lastname>' + row.lName + '</lastname>';
            xmlFile += '<nationality>' + row.nat + '</nationality>'
            xmlFile += '</author>';
            done = 1;
        });

        while(!done) {
            node.loop();
        }

        xmlFile += '</authorlist>';
        res.send(xmlFile);
    });
});

app.get('/books/all', function(req, res) {

    console.log("Entered get for find all books");
    res.set('Content-type', 'text/xml');
    var xmlFile = '<?xml version="1.0" encoding="UTF-8"?>';
    xmlFile += '<booklist>';
    var done = 0;
    var SQL = `SELECT bookID as id,
        title as title,
        authorID as aId FROM book`;

    db.serialize(function() {
        db.each(SQL, (err, row) => {
            if (err) {
                console.error(err.message);
            }
            xmlFile += '<book>';
            xmlFile += '<bookid>' + row.id + ' </bookid>';
            xmlFile += '<booktitle>' + row.title + ' </booktitle>';
            xmlFile += '<authorId>' + row.aId + ' </authorId>';
            xmlFile += '</book>';
            done = 1;
        });

        while(!done) {
            node.loop();
        }

        xmlFile += '</booklist>';
        res.send(xmlFile);
    });
});

/*
*   GET
*/

app.get('/:table/:id', function(req, res) {

    console.log("Entered app.get");
    res.set('Content-type', 'text/xml');
    var id = req.param('id');
    var table = req.param('table');
    var idType = req.param('table')+"Id";

    console.log(`${table} from request: ${id} `);
    var xmlFile = '<?xml version="1.0" encoding="UTF-8"?>';
    
    switch(table) {
        case "books":
            var SQL = `SELECT bookID as id,
                title as booktitle,
                authorID as aId FROM book
                WHERE bookID = ?`;
            console.log(SQL);
            
            db.serialize(function() {
                db.get(SQL, [id], (err, row) => {
                    if (err) {
                        console.error(err.message);
                    }
                    var parsedxml = js2xmlparser.parse("book", row);
                    console.log(parsedxml);
                    res.send(parsedxml);
                });
            });
            break;

        case "authors":
            var SQL = `SELECT authorID as aId,
                    firstname as firstname,
                    lastname as lastname,
                    nationality as nationality FROM author
                    WHERE authorID = ?`;
                console.log(SQL);

                db.serialize(function() {
                    db.get(SQL, [id], (err, row) => {
                        if (err) {
                            console.error(err.message);
                        }
                        xmlFile += '<author>';
                        xmlFile += '<authorid>' + row.aId + ' </authorid>';
                        xmlFile += '<firstname>' + row.firstname + ' </firstname>';
                        xmlFile += '<lastname>' + row.lastname + ' </lastname>';
                        xmlFile += '<nationality>' + row.nationality + ' </lastname>';
                        xmlFile += '</author>';
                        console.log("res: " + res);
                        console.log("xmlfile: " + xmlFile);
                        var parsedxml = js2xmlparser.parse("author", row);
                        console.log(parsedxml);
                        res.send(parsedxml);
                    });
                });
            break;
        default:
            res.send("I am error");
            break;
    }
});

/*
*   POST
*/

app.post('/books', function(req, res) {
    //console.log("POST " + req.param('id') +" "+ req.param('table'));
    res.set('Content-type', 'text/xml');
    const { table, id } = req;
    var xmlFile = '<?xml version="1.0" encoding="UTF-8"?>';
    
    var data = {
        bookID: req.body.bookID,
        title: req.body.title,
        authorID: req.body.authorID
    }

    var SQL = `INSERT INTO book(bookID, title, authorID) VALUES (?,?,?);`;
    var params = [data.bookID, data.title, data.authorID];
    console.log(SQL);
    db.serialize(function() {
        db.run(SQL, params, (err, result) => {
            if (err) {
                console.error(err.message);
            }
            console.log("res: " + res);
            console.log("xmlfile: " + xmlFile);
            //res.send(xmlFile);
            res.json({
                "message": "success",
                "data": data,
                "id" : this.lastID
            })
        });
    });
    //res.send(1);
});

/*
*   PUT
*/
app.put('/:table/:id', function(req, res) {
    res.set('Content-type', 'text/xml');
    const { table, id } = req;
    var xmlFile = '<?xml version="1.0" encoding="UTF-8"?>';    
    var SQL = `UPDATE books
        SET title = ?
        WHERE bookID = ?`;
    console.log("PUT " + req.param('id') +" "+ req.param('table'));
    res.send("put");
});

/*
*   DELETE
*/
app.delete('/:table/:id', function(req, res) {
    console.log("DELETE " + req.param('id') +" "+ req.param('table'));
    res.send("delete");
});

// db.close((err) => {
//     if (err) {
//         return console.error(err.message);
//     }
//     console.log('\nClose the database connection.');
// });