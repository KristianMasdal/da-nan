#! /bin/bash

docker build -t nan/mp3 .

docker run -dit -p 8080:80 --name cgiserver nan/mp3 




