#! /bin/bash

docker container rm restapi
docker build . --rm -t nodejs-rest

docker run --name restapi -e VERSION=1.1 -p 9000:3000 nodejs-rest
